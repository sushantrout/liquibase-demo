package com.test;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

public class FreeMarkerExampleEmployee {

    public static void main(String[] args) throws IOException, TemplateException {
        Employee employee = new Employee("John Doe", 30, "Java, Python, SQL");
        String template = "Employee details: ${employee.name}, ${employee.age}, ${employee.skills}";

        String replaced = replacePlaceholdersWithFreeMarker(template, employee);
        System.out.println("Replaced String: " + replaced);
    }

    public static String replacePlaceholdersWithFreeMarker(String templateString, Employee employee)
            throws IOException, TemplateException {
        Configuration cfg = new Configuration(Configuration.VERSION_2_3_31);
        Template template = new Template("template", templateString, cfg);

        Map<String, Object> input = new HashMap<>();
        input.put("employee", employee);

        StringWriter writer = new StringWriter();
        template.process(input, writer);

        return writer.toString();
    }
}
